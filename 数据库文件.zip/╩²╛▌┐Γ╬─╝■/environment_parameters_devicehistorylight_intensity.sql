INSERT INTO `environment_parameters_devicehistorylight_intensity` (`id`, `light_intensity`, `time`, `device_index_id`) VALUES (1, 145, '2021-7-15 17:03:46', 123);
INSERT INTO `environment_parameters_devicehistorylight_intensity` (`id`, `light_intensity`, `time`, `device_index_id`) VALUES (2, 145, '2021-7-15 17:03:56', 123);
INSERT INTO `environment_parameters_devicehistorylight_intensity` (`id`, `light_intensity`, `time`, `device_index_id`) VALUES (3, 145, '2021-7-15 17:04:06', 123);
INSERT INTO `environment_parameters_devicehistorylight_intensity` (`id`, `light_intensity`, `time`, `device_index_id`) VALUES (4, 145, '2021-7-15 17:08:53', 123);
INSERT INTO `environment_parameters_devicehistorylight_intensity` (`id`, `light_intensity`, `time`, `device_index_id`) VALUES (5, 145, '2021-7-15 17:09:04', 123);
INSERT INTO `environment_parameters_devicehistorylight_intensity` (`id`, `light_intensity`, `time`, `device_index_id`) VALUES (6, 145, '2021-7-15 17:09:14', 123);
INSERT INTO `environment_parameters_devicehistorylight_intensity` (`id`, `light_intensity`, `time`, `device_index_id`) VALUES (7, 16.66, '2021-7-15 19:37:58', 123);
