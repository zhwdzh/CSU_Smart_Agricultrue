INSERT INTO `environment_parameters_devicehistoryultraviolet` (`id`, `ultraviolet`, `time`, `device_index_id`) VALUES (1, 0.28, '2021-7-14 20:08:30', 124);
INSERT INTO `environment_parameters_devicehistoryultraviolet` (`id`, `ultraviolet`, `time`, `device_index_id`) VALUES (2, 0.01, '2021-7-15 17:08:54', 124);
INSERT INTO `environment_parameters_devicehistoryultraviolet` (`id`, `ultraviolet`, `time`, `device_index_id`) VALUES (3, 0.01, '2021-7-15 17:09:05', 124);
INSERT INTO `environment_parameters_devicehistoryultraviolet` (`id`, `ultraviolet`, `time`, `device_index_id`) VALUES (4, 0.01, '2021-7-15 17:09:15', 124);
INSERT INTO `environment_parameters_devicehistoryultraviolet` (`id`, `ultraviolet`, `time`, `device_index_id`) VALUES (5, 0, '2021-7-15 19:37:58', 124);
