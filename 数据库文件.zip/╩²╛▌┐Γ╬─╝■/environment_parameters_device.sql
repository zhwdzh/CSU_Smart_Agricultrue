INSERT INTO `environment_parameters_device` (`index`, `name`, `device_type`) VALUES (121, '温湿度传感器1', '温湿度传感器');
INSERT INTO `environment_parameters_device` (`index`, `name`, `device_type`) VALUES (122, '二氧化碳传感器1', '二氧化碳传感器');
INSERT INTO `environment_parameters_device` (`index`, `name`, `device_type`) VALUES (123, '光照强度传感器1', '光照强度传感器');
INSERT INTO `environment_parameters_device` (`index`, `name`, `device_type`) VALUES (124, '紫外线强度传感器1', '紫外线强度传感器');
