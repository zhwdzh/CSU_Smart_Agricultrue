from rest_framework import serializers
from django.contrib.auth.models import User


# 注册信息序列化
class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'password', 'email', 'first_name', 'last_name']
        extra_kwargs = {
            # 'username': {'write_only': True, 'required': True, },
            # 'is_superuser': {'write_only': True, 'required': False, 'default': 0},
            # 'email': {'write_only': True, 'required': True, },
            'password': {'write_only': True, 'required': True, },
            # 'first_name': {'write_only': True, 'required': True, },

        }

    # 创建用户
    def create(self, validated_data):
        user = User(**validated_data)
        user.set_password(validated_data['password'])
        user.save()
        return user

