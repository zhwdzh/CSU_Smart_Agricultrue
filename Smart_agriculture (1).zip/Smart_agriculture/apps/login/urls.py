from django.urls import path, include
from .views import *
from rest_framework import routers
from apps.users import views
from rest_framework_jwt.views import obtain_jwt_token


app_name = '[login]'


urlpatterns = [
    path('login', obtain_jwt_token, name='login'),
    path('register', RegisterView.as_view(), name='register'),
    # path('logout', LogoutView.as_view(), name='logout'),
    # path('getuser', GetUserByJwtView.as_view(), name='getuser'),
]
