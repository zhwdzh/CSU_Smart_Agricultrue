from django.contrib.auth import authenticate, logout
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views import View
from rest_framework.generics import GenericAPIView,mixins,ListAPIView
from rest_framework_jwt.serializers import jwt_encode_handler, jwt_payload_handler

from .serializers import RegisterSerializer
from django.contrib.auth.models import User


# Create your views here.
class RegisterView(mixins.CreateModelMixin, GenericAPIView):
    serializer_class = RegisterSerializer
    queryset = User.objects.all()
    permission_classes = []

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


"""
class GetUserByJwtView(ListAPIView):
    def get(self, user_id):
        user = User.objects.get_by_natural_key('admin')
        payload = jwt_payload_handler(user)
        return jwt_encode_handler(payload)
        """
