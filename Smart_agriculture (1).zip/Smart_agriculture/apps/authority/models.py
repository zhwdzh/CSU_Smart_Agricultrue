from django.db import models


# Create your models here.
# 自定义一些权限
class Authority(models.Model):
    class Meta:
        permissions = (
            ('authority_users', '用户管理'),
            ('authority_logs', '日志管理'),
            ('authority_scene', '场景管理'),
            ('authority_device', '设备管理'),
        )
