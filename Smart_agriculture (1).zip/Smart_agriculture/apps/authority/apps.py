from django.apps import AppConfig


class AuthorityConfig(AppConfig):
    name = 'authority'
