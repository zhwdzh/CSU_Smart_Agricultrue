from socket import socket, AF_INET, SOCK_STREAM

from apscheduler.schedulers.background import BackgroundScheduler
from django.db.models import Q
from rest_framework.utils import json

# Create your views here.
from apps.alarmsystem.models import *
from apps.automode.serializers import *
from apps.controlled_devices.models import *
from apps.environment_parameters.models import *
from apps.automode.models import *
from apps.logs.views import *
from rest_framework.generics import CreateAPIView


def test_job():
    # conn = pymysql.connect(host='127.0.0.1', port=3306, database='Smart_agriculture', user='admin_lyj',
    #                        password='8208180529', charset='utf8')
    temperature = DeviceHistoryTempHum.objects.last().temperature
    humidity = DeviceHistoryTempHum.objects.last().humidity
    light_intensity = DeviceHistoryLight_intensity.objects.last().light_intensity
    carbon_dioxide = DeviceHistoryCarbon_dioxide.objects.last().carbon_dioxide
    ultraviolet = DeviceHistoryUltraviolet.objects.last().ultraviolet
    fan = DeviceHistoryFan.objects.last().fan
    engine = DeviceHistoryEngine.objects.last().engine
    brightness = DeviceHistoryLight.objects.last().brightness
    fumes = FumesHistory.objects.last().fumes
    methane = MethaneHistory.objects.last().methane
    firelight = FirelightHistory.objects.last().firelight
    alarmlight = AlarmHistory.objects.last().alarmlight
    alerter = AlarmHistory.objects.last().alerter
    # automode = AutomodeHistory.objects.last().automode
    # if automode == 1:
    if 1:
        if (temperature >= 29.72) and (fan == 0) and (alarmlight == 0 and alerter == 0):
            sendmsg(171, "fan", True)
            add_autologs(deviceid=171, devicename='fan', logcontent='温度过高，已自动打开风机')
        elif (temperature < 27.72) and (fan == 1) and (alarmlight == 0 and alerter == 0):
            sendmsg(171, "fan", False)
            add_autologs(deviceid=171, devicename='fan', logcontent='温度恢复正常，已自动关闭风机')
        if (humidity <= 55.47) and (engine == 0) and (alarmlight == 0 and alerter == 0):
            sendmsg(161, "engine", True)
            add_autologs(deviceid=161, devicename='engine', logcontent='湿度过低，已自动打开洒水器')
        elif (humidity > 55.47) and (engine == 1) and (alarmlight == 0 and alerter == 0):
            sendmsg(161, "engine", False)
            add_autologs(deviceid=161, devicename='engine', logcontent='湿度恢复正常，已自动关闭洒水器')
        if (light_intensity <= 140) and (brightness == 0):
            sendmsg(111, "brightness", 40)
            add_autologs(deviceid=111, devicename='light', logcontent='光照强度过低，已自动打开高亮LED灯')
        elif (light_intensity > 140) and (brightness != 0):
            sendmsg(111, "brightness", 0)
            add_autologs(deviceid=111, devicename='light', logcontent='光照强度恢复正常，已自动关闭高亮LED灯')
        # 火警
        if fumes == 1 and (alarmlight == 0 or alerter == 0):
            sendalarmmsg(151, "alarmlight", "alerter", True, True)
            sendmsg(161, "engine", True)
            sendmsg(171, "fan", False)
            add_autologs(deviceid=151, devicename='alarmlight,alerter,engine', logcontent='警告！警告！检测到烟雾，'
                                                                                          '已自动打开洒水喷头，报警灯和报警器,已自动关闭风机')
        elif methane == 1 and (alarmlight == 0 or alerter == 0):
            sendalarmmsg(151, "alarmlight", "alerter", True, True)
            sendmsg(161, "engine", True)
            sendmsg(171, "fan", False)
            add_autologs(deviceid=151, devicename='alarmlight,alerter,engine', logcontent='警告！警告！检测到甲烷，'
                                                                                          '已自动打开洒水喷头，报警灯和报警器,已自动关闭风机')
        elif firelight == 1 and (alarmlight == 0 or alerter == 0):
            sendalarmmsg(151, "alarmlight", "alerter", True, True)
            sendmsg(161, "engine", True)
            sendmsg(171, "fan", False)
            add_autologs(deviceid=151, devicename='alarmlight,alerter,engine', logcontent='警告！警告！检测到火光，'
                                                                                          '已自动打开洒水喷头，报警灯和报警器,已自动关闭风机')
        elif (fumes == 0 and methane == 0 and firelight == 0) and (alarmlight == 1 or alerter == 1):
            sendalarmmsg(151, "alarmlight", "alerter", False, False)
            sendmsg(161, "engine", False)
            add_autologs(deviceid=151, devicename='alarmlight,alerter,engine', logcontent='自动灭火成功，已关闭洒水喷头')
    info = {
        'temperature': temperature,
        'humidity': humidity,
        'light_intensity': light_intensity,
        'carbon_dioxide': carbon_dioxide,
        'ultraviolet': ultraviolet,
        'engine': engine,
        'brightness': brightness,
        'fan': fan,
        'fumes': fumes,
        'methane': methane,
        'firelight': firelight,
        'alarmlight': alarmlight,
        'alerter': alerter,
    }
    print(info)


scheduler = BackgroundScheduler()
scheduler.add_job(test_job, )

scheduler = BackgroundScheduler()
scheduler.add_job(test_job, 'interval', seconds=8, id="test39", )

# scheduler.add_jobstore(DjangoJobStore(), "default")

# @register_job(scheduler, "interval", seconds=8, id="test37", misfire_grace_time=1)

# print(info)
# raise ValueError("Olala!")

try:
    # This is here to simulate application activity (which keeps the main thread alive).
    scheduler.start()
    print("Scheduler started!")
except (KeyboardInterrupt, SystemExit):
    # Not strictly necessary if daemonic mode is enabled but should be done if possible
    scheduler.shutdown()
    print('Exit The Job!')


def sendmsg(device_index, device_name, value):
    HOST = "192.168.43.194"
    PORT = 10001
    send_content = json.dumps({device_name: value, "device_index": device_index})
    # send_content = '{"msg_type": "order", "scene_code":"' + scene_code + '","device":"' + device + '",
    # "content":"' \ + operate + '"}'
    content = send_content + "\r\n\r\n"
    try:
        s = socket(AF_INET, SOCK_STREAM)
        s.connect((HOST, PORT))
        s.send(send_content.encode(encoding='utf-8'))
        print(content + "发送成功")
        s.close()
    except:
        print("发送失败")


def sendalarmmsg(device_index, device_name1, device_name2, value1, value2):
    HOST = "192.168.43.194"
    PORT = 10001
    send_content = json.dumps({device_name1: value1, device_name2: value2, "device_index": device_index})
    # send_content = '{"msg_type": "order", "scene_code":"' + scene_code + '","device":"' + device + '",
    # "content":"' \ + operate + '"}'
    content = send_content + "\r\n\r\n"
    try:
        s = socket(AF_INET, SOCK_STREAM)
        s.connect((HOST, PORT))
        s.send(send_content.encode(encoding='utf-8'))
        print(content + "发送成功")
        s.close()
    except:
        print("发送失败")


# 自动控制模式历史状态记录
class AutomodeHistoryView(ListAPIView):
    queryset = AutomodeHistory.objects.all()
    serializer_class = AutomodeSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return AutomodeHistory.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 改变控制状态
class AutomodeChangeView(CreateAPIView):
    queryset = AutomodeHistory.objects.all()
    serializer_class = AutomodeChangeSerializer
