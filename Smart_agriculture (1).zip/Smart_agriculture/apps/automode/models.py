from django.db import models
from django.utils import timezone


# Create your models here.
# 自动模式开启历史
class AutomodeHistory(models.Model):
    automode = models.BooleanField(default=False)
    time = models.DateTimeField(default=timezone.now)


