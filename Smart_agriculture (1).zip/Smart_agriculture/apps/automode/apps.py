from django.apps import AppConfig


class AutomodeConfig(AppConfig):
    name = 'automode'
