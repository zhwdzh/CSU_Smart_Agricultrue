from django.urls import path

from apps.automode.views import AutomodeHistoryView, AutomodeChangeView

app_name = '[automode]'


urlpatterns = [
    # path('automode/<str:start>/<str:end>', AutomodeHistoryView.as_view(), 'automode'),
    # path('automodechange', AutomodeChangeView.as_view(), 'automodechange')
]
