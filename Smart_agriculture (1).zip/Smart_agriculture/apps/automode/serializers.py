from rest_framework import serializers
from apps.automode.models import *


class AutomodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AutomodeHistory
        fields = '__all__'


# 改变自动控制模式状态
class AutomodeChangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AutomodeHistory
        fields = ['automode']
