from django.urls import path
from .views import *

app_name = '[users]'


urlpatterns = [
    path('userinfo', UserSelfInfoView.as_view(), name="userinfo"),                            # 根据token返回用户个人信息
    path('users/<int:pk>', UserRetrieveUpdateDeleteView.as_view(), name='users'),             # 用户详情、编辑、删除
    path('userlist', UserListView.as_view(), name='userlist'),                                # 用户列表
    path('personinfo/<int:pk>', PersonalInfoRetrieveUpdate.as_view(), name='personinfo'),    # 个人信息查看修改
    path('permission/<int:groupid>', GroupPermsView.as_view(), name='permission'),
]
