from django.contrib.auth.models import User, Group
from rest_framework import serializers


# 用户名单序列化
class UserListSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'          # 序列User模型中的所有属性
        # fields = ('id',)
        # fields = ['id']
        # exclude = ['password']
        # 指定只读字段
        # read_only_fields = ('username',)
        # 指定只写字段
        # write_only_fields = ('password',)
        # extra_kwargs用来配置额外的字段参数
        extra_kwargs = {
            'password': {'write_only': True, 'required': False},
            # 'username': {'required': False, 'read_only': True, 'label': '22222222', 'help_text': '333333333'},
        }
        depth = 2


# 用户信息序列化
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'password', 'email', 'is_superuser', 'date_joined']

        extra_kwargs = {
            'username': {'read_only': True},
            'date_joined': {'read_only': True}
        }

    def update(self, instance, validated_data):
        print(validated_data)
        for key, value in validated_data.items():
            setattr(instance, key, value)
        if 'password' in validated_data:
            instance.set_password(validated_data['password'])
        instance.save()
        return instance


# 个人信息序列化器
class PersonalInfoSerializer(serializers.ModelSerializer):
    # 新增模型以外的字段 默认必须填
    current_password = serializers.CharField(max_length=30, write_only=True, required=False)

    class Meta:
        model = User
        fields = ('username', 'password', 'email', 'first_name', 'current_password')
        # 默认非必填
        extra_kwargs = {
            'username': {'read_only': True},
            'password': {'write_only': True, 'required': False},
        }

    def validate(self, attrs):
        # 当修改密码时，需要验证当前密码是否正确
        if 'password' in attrs:                      # 修改密码
            current_password = attrs.get('current_password')
            if current_password is None:
                raise serializers.ValidationError('需要提供旧密码')
            if not self.instance.check_password(current_password):
                raise serializers.ValidationError('验证当前密码错误')
        return attrs

    def update(self, instance, validated_data):
        print(validated_data)
        for key, value in validated_data.items():
            setattr(instance, key, value)
        if 'password' in validated_data:
            instance.set_password(validated_data['password'])
        instance.save()
        return instance
