import os

from django.shortcuts import render

# Create your views here.
from drf_yasg.utils import swagger_auto_schema
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_jwt.serializers import jwt_decode_handler

from logs.views import add_logs
from .serializers import *
from rest_framework.pagination import PageNumberPagination
from django.contrib.auth.models import User, Group, Permission
from rest_framework import viewsets, status
from rest_framework.generics import ListAPIView, CreateAPIView, RetrieveAPIView, UpdateAPIView, DestroyAPIView
from rest_framework import filters
from rest_framework.generics import GenericAPIView, mixins
from django.contrib.auth.models import User, Group
from .serializers import PersonalInfoSerializer
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi

Header_token = openapi.Parameter('Authorization', openapi.IN_HEADER, description="Token（ Format: JWT {Token Value}）",
                                 type=openapi.TYPE_STRING)
Accept_Language = openapi.Parameter('Accept-Language', openapi.IN_HEADER, description="Language: en or zh-CN",
                                    type=openapi.TYPE_STRING)
base_swagger = {
    'manual_parameters': [Header_token, Accept_Language],
    'request_body': openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['groupid', "permissionid"],
            properties={
                'groupid': openapi.Schema(type=openapi.TYPE_INTEGER),
                'permissionids': openapi.Schema(
                    type=openapi.TYPE_ARRAY,
                    items=openapi.Items(type=openapi.TYPE_INTEGER)
                ),
            },
        ),
}


def get_swagger_docs(filename):
    DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'docs')
    with open(os.path.join(DIR, filename), 'r', encoding='utf-8') as f:
        return f.read()


personinfo_read_swagger = dict({
    'tags': ['用户模块'],
    'operation_summary': '获得用户信息',
    'operation_description': get_swagger_docs('demo.md')
})

personinfo_update_swagger = dict({
    'tags': ['用户模块'],
    'operation_summary': '更新个人信息',
    'operation_description': get_swagger_docs('demo.md')
})

user_create_swagger = dict({
    'tags': ['权限模块'],
    'operation_summary': '角色授权',
})


# 用户管理：用户列表（分页、搜索、过滤、排序）/ 用户详情get / 用户删除delete / 用户编辑put、patch


# # 用户列表和用户的新增--学习
# class UserListView11(ListAPIView, CreateAPIView):
#     # queryset = User.objects.all()# 获取所有用户
#     # queryset = User.objects.filter(is_superuser=1).order_by('-id')[0:1]# 获取超级管理员
#     # queryset = User.objects.exclude(is_superuser=1)# 获取非管理员
#     queryset = User.objects.filter(username__contains='t')
#     serializer_class = UserListSerializer
#
#     # @swagger_auto_schema(**user_read_swagger)
#     def get(self, request, *args, **kwargs):
#         return self.list(request, *args, **kwargs)
#
#     # @swagger_auto_schema(**user_read_swagger)
#     def post(self, request, *args, **kwargs):
#         # 新增操作日志
#         # user = request.user
#         # log_ip = request.META.REMOTE_ADDR
#         print(request.user)
#         print(request.META.REMOTE_ADDR)  # request.META.get('HTTP_AUTHORIATION')获取前端在头部的authorization中存放token
#         # addlogs(user,'用户管理模块','新增用户信息',log_ip)
#         return self.create(request, *args, **kwargs)


# 自定义分页类
class SelfPagination(PageNumberPagination):
    page_size = 5  # 每页显示几条数据
    page_size_query_param = 'page_size'  # 配置每页显示条数的参数名
    max_page_size = 20
    page_query_param = 'page'  # 分页参数名称


# 用户列表
class UserListView(ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserListSerializer
    pagination_class = SelfPagination  # 配置分页
    filter_backends = (filters.OrderingFilter, filters.SearchFilter)
    # 排序
    ordering_fields = ('id', 'username')
    ordering = ('id',)  # 默认排序方式
    # 搜索-模糊查询
    search_fields = ('username', 'email')

    # 过滤


# 用户的详情、编辑、删除
class UserRetrieveUpdateDeleteView(RetrieveAPIView, DestroyAPIView, UpdateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    lookup_url_kwarg = 'pk'

    def delete(self, request, *args, **kwargs):
        # 新增操作日志
        logip = request.META.get('REMOTE_ADDR', '0.0.0.0')  # 获得ip
        add_logs(LogType='用户模块', LogContent='删除用户', LogIp=logip, UserId=request.user.id)
        return self.destroy(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        logip = request.META.get('REMOTE_ADDR', '0.0.0.0')  # 获得ip
        add_logs(LogType='用户模块', LogContent='更新用户', LogIp=logip, UserId=request.user.id)
        return self.update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        logip = request.META.get('REMOTE_ADDR', '0.0.0.0')  # 获得ip
        add_logs(LogType='用户模块', LogContent='更新用户', LogIp=logip, UserId=request.user.id)
        return self.partial_update(request, *args, **kwargs)


# 根据token获取用户信息
class UserSelfInfoView(ListAPIView):
    permission_classes = []
    queryset = User.objects.all()
    serializer_class = UserListSerializer

    def get_queryset(self):
        token = self.request.META.get("HTTP_AUTHORIZATION")
        token = token.split(' ')[1]
        token_user = jwt_decode_handler(token)
        user_id = token_user['user_id']
        return self.queryset.filter(id=user_id)


# 个人信息查看更新视图
class PersonalInfoRetrieveUpdate(GenericAPIView):
    queryset = User.objects.all()
    serializer_class = PersonalInfoSerializer
    lookup_url_kwarg = 'pk'
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(**personinfo_read_swagger)
    def get(self, request, *args, **kwargs):
        ser = self.get_serializer(request.user)
        return Response(data=ser.data, status=200)

    @swagger_auto_schema(**personinfo_update_swagger)
    def put(self, request, *args, **kwargs):
        ser = self.get_serializer(request.user, request.data)
        ser.is_valid(raise_exception=True)  # 验证失败时，抛出异常
        ser.save()
        return Response(data=ser.data, status=200)


# 角色授权
class GroupPermsView(APIView):
    module_perms = ['authority.authority']
    permission_classes = []

    @swagger_auto_schema(**user_create_swagger)
    def post(self, request, *args, **kwargs):
        print(request.data.get('groupid'))
        print(request.data)
        group = Group.objects.get(id=request.data.get('groupid'))
        # 清空权限:
        group.permissions.clear()
        for permissionid in request.data.get('permissionids'):
            permission = Permission.objects.get(id=permissionid)
            # 添加权限:
            group.permissions.add(permission)
        return Response(status=200, data={'msg': '角色授权成功', 'code': 200})
