from django.urls import path
from .views import *

app_name = '[environment_parameters]'


urlpatterns = [
    # 用户列表和新增
    # path('environment_parameters', EnvironmentParametersView.as_view(), name="environment_parameters"),
    # path('addtest', AddTestView.as_view(), name="add_test"),
    # 获取温度数据路径
    path('temperture/<str:start>/<str:end>', TemperatureView.as_view(), name='temperature'),
    # 获取温度数据路径
    path('humidity/<str:start>/<str:end>', HumidityView.as_view(), name='humidity'),
    # 获取光照强度数据路径
    path('light_intensity/<str:start>/<str:end>', Light_intensityHistoryListView.as_view(), name='light_intensity'),
    # 获取二氧化碳浓度数据路径
    path('carbon_dioxide/<str:start>/<str:end>', Carbon_dioxideHistoryListView.as_view(), name='carbon_dioxide'),
    # 获取紫外线强度数据路径
    path('ultraviolet/<str:start>/<str:end>', UltravioletHistoryListView.as_view(), name='ultraviolet'),


    # 用户详情、编辑、删除
    # path('users/<int:pk>', UserRetriveUpdateDeleteView.as_view(), name='users')
]
