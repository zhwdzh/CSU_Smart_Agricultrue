from apps.environment_parameters.models import *
from rest_framework import serializers


# 环境参数序列化
# class EnvironmentParameterSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = EnvironmentParameter
#         fields = '__all__'  # 序列化Environment_parameters中所有字段
#
#
# class AddTestSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = EnvironmentParameter
#         fields = '__all__'
# fields = {'temperature', 'humidity', 'light_intensity', 'carbon_dioxide', 'Ultraviolet'}
# extra_kwargs = {
#     'temperature': {'write_only': True, 'required': True, },
#     'humidity': {'write_only': True, 'required': True, },
#     'light_intensity': {'write_only': True, 'required': True, },
#     'carbon_dioxide': {'write_only': True, 'required': True, },
#     'Ultraviolet': {'write_only': True, 'required': True, },
# }


# 温度数据序列化
class TemperatureSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryTempHum
        fields = ['temperature', 'time']


class HumiditySerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryTempHum
        fields = ['humidity', 'time']


# 光照强度数据序列化
class Light_intensitySerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryLight_intensity
        fields = ['light_intensity', 'time']


# 二氧化碳浓度数据序列化
class Carbon_dioxideSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryCarbon_dioxide
        fields = ['carbon_dioxide', 'time']


# 紫外线强度数据序列化
class UltravioletSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryUltraviolet
        fields = ['ultraviolet', 'time']

