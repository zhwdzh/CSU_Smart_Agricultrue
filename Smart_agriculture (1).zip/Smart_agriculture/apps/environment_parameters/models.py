from django.db import models
from django.utils import timezone


# Create your models here.
# class EnvironmentParameter(models.Model):
#     # region_id = models.AutoField(db_index=True, primary_key=True, default=100)  # 区域ID
#     temperature = models.IntegerField(default=0)                                # 温度
#     humidity = models.IntegerField(default=0)                                   # 湿度
#     light_intensity = models.IntegerField(default=0)                            # 光照强度
#     carbon_dioxide = models.IntegerField(default=0)                             # 二氧化碳浓度
#     ultraviolet = models.IntegerField(default=0)                                # 紫外线强度
#     datetime = models.DateTimeField(default=timezone.now)                       # 日期时间


# 设备表
class Device(models.Model):
    index = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=30)
    device_type = models.CharField(max_length=30)


# 温湿度历史数据表
class DeviceHistoryTempHum(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=121)
    temperature = models.FloatField(default=0)              # 温度值
    humidity = models.FloatField(default=0)                 # 湿度值
    time = models.DateTimeField(default=timezone.now)


# 光照强度历史数据表
class DeviceHistoryLight_intensity(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=123)
    light_intensity = models.FloatField(default=0)          # 光照强度值
    time = models.DateTimeField(default=timezone.now)


# 二氧化碳浓度历史数据表
class DeviceHistoryCarbon_dioxide(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=122)
    carbon_dioxide = models.FloatField(default=0)           # 二氧化碳浓度值
    time = models.DateTimeField(default=timezone.now)


# 紫外线强度历史数据表
class DeviceHistoryUltraviolet(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=124)
    ultraviolet = models.FloatField(default=0)              # 紫外线强度值
    time = models.DateTimeField(default=timezone.now)
