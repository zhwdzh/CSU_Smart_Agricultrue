from django.apps import AppConfig


class EnvironmentParametersConfig(AppConfig):
    name = 'environment_parameters'
