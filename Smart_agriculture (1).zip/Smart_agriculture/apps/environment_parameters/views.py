from django.db.models import Q
from rest_framework.generics import ListAPIView
from rest_framework.pagination import PageNumberPagination

from .serializers import *


# 配置分页
class SelfPagination(PageNumberPagination):
    page_size = 2  # 每页显示几条数据
    page_size_query_param = 'page_size'  # 配置每页显示条数的参数名
    max_page_size = 20
    page_query_param = 'page'  # 分页参数名称


# Create your views here.
# 环境参数
# class EnvironmentParametersView(ListAPIView):
#     queryset = EnvironmentParameter.objects.all()
#     serializer_class = EnvironmentParameterSerializer
#
#
# class AddTestView(mixins.CreateModelMixin, GenericAPIView):
#     queryset = EnvironmentParameter.objects.all()
#     serializer_class = AddTestSerializer
#     permission_classes = []
#
#     def post(self, request, *args, **kwargs):
#         return self.create(request, *args, **kwargs)


# 获取温度数据视图
class TemperatureView(ListAPIView):
    queryset = DeviceHistoryTempHum.objects.all()
    serializer_class = TemperatureSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        # return Temperature.objects.filter(Q(addtime__gt = starttime) & Q(addtime__lt = endtime))[:10]
        return DeviceHistoryTempHum.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 获取湿度数据视图
class HumidityView(ListAPIView):
    # queryset = Temperature.objects.all()
    serializer_class = HumiditySerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        # return Temperature.objects.filter(Q(addtime__gt = starttime) & Q(addtime__lt = endtime))[:10]
        return DeviceHistoryTempHum.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 获取光照强度数据视图
class Light_intensityHistoryListView(ListAPIView):
    queryset = DeviceHistoryLight_intensity.objects.all()
    serializer_class = Light_intensitySerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return DeviceHistoryLight_intensity.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 获取二氧化碳浓度数据视图
class Carbon_dioxideHistoryListView(ListAPIView):
    queryset = DeviceHistoryCarbon_dioxide.objects.all()
    serializer_class = Carbon_dioxideSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return DeviceHistoryCarbon_dioxide.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 获取紫外线强度数据视图
class UltravioletHistoryListView(ListAPIView):
    queryset = DeviceHistoryUltraviolet.objects.all()
    serializer_class = UltravioletSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return DeviceHistoryUltraviolet.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})
