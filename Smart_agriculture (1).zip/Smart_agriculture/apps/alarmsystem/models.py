from django.db import models
from django.utils import timezone


# Create your models here.
# 报警系统设备表
class Device(models.Model):
    index = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=30)
    device_type = models.CharField(max_length=30)


# 烟雾传感器历史数据表
class FumesHistory(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=131)
    fumes = models.BooleanField(default=False)             # 烟雾报警
    time = models.DateTimeField(default=timezone.now)


# 甲烷传感器历史数据表
class MethaneHistory(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=132)
    methane = models.BooleanField(default=False)           # 甲烷报警
    time = models.DateTimeField(default=timezone.now)


# 火光传感器历史数据表
class FirelightHistory(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=133)
    firelight = models.BooleanField(default=False)         # 火光报警
    time = models.DateTimeField(default=timezone.now)


# 报警灯和报警器历史数据表
class AlarmHistory(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=151)
    alarmlight = models.BooleanField(default=False)        # 报警灯
    alerter = models.BooleanField(default=False)           # 报警器
    time = models.DateTimeField(default=timezone.now)
