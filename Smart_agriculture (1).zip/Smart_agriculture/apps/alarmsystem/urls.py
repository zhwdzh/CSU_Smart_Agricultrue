from django.urls import path
from .views import *

app_name = '[alarmsystem]'


urlpatterns = [
    path('fumes/<str:start>/<str:end>', FumesHistoryView.as_view(), name="fumes"),                   # 烟雾传感器历史报警记录视图路径
    path('methane/<str:start>/<str:end>', MethaneHistoryView.as_view(), name="methane"),             # 甲烷传感器历史报警记录视图路径
    path('firelight/<str:start>/<str:end>', FirelightHistoryView.as_view(), name="firelight"),       # 火光传感器历史报警记录视图路径
    path('alarm/<str:start>/<str:end>', AlarmHistoryView.as_view(), name="alarm"),                   # 报警灯和报警器历史报警记录视图路径
    path('alarmchange', AlarmChangeView.as_view(), name='alarmchange'),
    # 用户详情、编辑、删除
    # path('users/<int:pk>', UserRetriveUpdateDeleteView.as_view(), name='users')
]
