from socket import socket, AF_INET, SOCK_STREAM

from django.db.models import Q
from django.shortcuts import render
from rest_framework import status
from rest_framework.generics import ListAPIView, CreateAPIView
from rest_framework.response import Response
from rest_framework.utils import json

from .serializers import *


# Create your views here.
# 烟雾传感器历史报警记录视图
class FumesHistoryView(ListAPIView):
    queryset = FumesHistory.objects.all()
    serializer_class = FumesSerializer


# 甲烷传感器历史报警记录视图
class MethaneHistoryView(ListAPIView):
    queryset = MethaneHistory.objects.all()
    serializer_class = MethaneSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return MethaneHistory.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 火光传感器历史报警记录视图
class FirelightHistoryView(ListAPIView):
    queryset = FirelightHistory.objects.all()
    serializer_class = FirelightSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return FirelightHistory.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 报警灯和报警器历史报警记录视图
class AlarmHistoryView(ListAPIView):
    queryset = AlarmHistory.objects.all()
    serializer_class = AlarmSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return AlarmHistory.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 报警器和报警灯控制,向数据库中插入数据，并发送信息至中间层
class AlarmChangeView(CreateAPIView):
    queryset = AlarmHistory.objects.last()
    serializer_class = AlarmChangeSerializer

    def post(self, request, *args, **kwargs):
        alarmlight = request.data.get('alarmlight', None)
        alerter = request.data.get('alerter', None)
        HOST = "192.168.43.194"
        PORT = 10001
        send_content = json.dumps({"alarmlight": alarmlight, 'alerter': alerter, "device_index": 151})
        content = send_content + "\r\n\r\n"
        try:
            s = socket(AF_INET, SOCK_STREAM)
            s.connect((HOST, PORT))
            s.send(content.encode(encoding='utf-8'))
            print(send_content + "发送成功")
            s.close()
        except:
            return Response(data={'code': 400, 'detail': '操作失败'}, status=status.HTTP_400_BAD_REQUEST)
        return self.create(request, *args, **kwargs)


