from django.apps import AppConfig


class AlarmsystemConfig(AppConfig):
    name = 'alarmsystem'
