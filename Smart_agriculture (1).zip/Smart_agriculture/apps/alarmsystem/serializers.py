from apps.alarmsystem.models import *
from rest_framework import serializers


# 烟雾报警信息序列化
class FumesSerializer(serializers.ModelSerializer):
    class Meta:
        model = FumesHistory
        fields = ['fumes', 'time']   # 序列化Fumes中所有字段


# 甲烷报警信息序列化
class MethaneSerializer(serializers.ModelSerializer):
    class Meta:
        model = MethaneHistory
        fields = ['methane', 'time']


# 火光报警信息序列化
class FirelightSerializer(serializers.ModelSerializer):
    class Meta:
        model = FirelightHistory
        fields = ['firelight', 'time']


# 报警灯和报警器信息序列化
class AlarmSerializer(serializers.ModelSerializer):
    class Meta:
        model = AlarmHistory
        fields = ['alarmlight', 'alerter', 'time']


# 报警灯和报警器信息序列化
class AlarmChangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AlarmHistory
        fields = ['alarmlight', 'alerter']

