from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.generics import GenericAPIView, mixins
from django.contrib.auth.models import User

from users2 import docs
from .serializers import PersonalInfoSerializer
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi

import os


# Create your views here.
Header_token = openapi.Parameter('Authorization', openapi.IN_HEADER, description="Token（ Format: JWT {Token Value}）",
                                 type=openapi.TYPE_STRING)
Accept_Language = openapi.Parameter('Accept-Language', openapi.IN_HEADER, description="Language: en or zh-CN",
                                    type=openapi.TYPE_STRING)

base_swagger = {
    'manual_parameters': [Header_token, Accept_Language],
}


def get_swagger_docs(filename):
    DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'docs')
    with open(os.path.join(DIR, filename), 'r', encoding='utf-8') as f:
        return f.read()


personinfo_read_swagger = dict({
    'tags': ['用户模块'],
    'operation_summary':'获取个人信息',
    'operation_description': get_swagger_docs('personinfo_read.md')
}, **base_swagger)


personinfo_update_swagger = dict({
    'tags': ['用户模块'],
    'operation_summary':'更新个人信息',
    'operation_description': get_swagger_docs('personinfo_update.md')
}, **base_swagger)


class PersonalInfoRetriveUpdate(GenericAPIView):
    queryset = User.objects.all()
    serializer_class = PersonalInfoSerializer
    lookup_url_kwarg = 'pk'
    permission_classes = [ IsAuthenticated ]

    @swagger_auto_schema(**personinfo_read_swagger)
    def get(self, request, *args, **kwargs):
        ser = self.get_serializer(request.user)
        return Response(data=ser.data, status=200)

    @swagger_auto_schema(**personinfo_update_swagger)
    def put(self, request, *args, **kwargs):
        ser = self.get_serializer(request.user, request.data)
        ser.is_valid(raise_exception=True)  # 验证失败时，抛出异常
        ser.save()
        return Response(data=ser.data, status=200)
