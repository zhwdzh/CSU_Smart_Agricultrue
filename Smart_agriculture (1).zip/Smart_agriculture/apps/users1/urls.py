from django.urls import path, include
from .views import *

app_name = '[users]'

urlpatterns = [
    path('personinfo/<int:pk>/', PersonalInfoRetriveUpdate.as_view(), name='personinfo'),
]
