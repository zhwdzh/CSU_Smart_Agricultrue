from django.contrib.auth.models import User, Group
from rest_framework import serializers


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ('url', 'username', 'email', 'groups')


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ('url', 'name')


class PersonalInfoSerializer(serializers.ModelSerializer):
    # 新增模型以外的字段 默认必须填
    current_password = serializers.CharField(max_length=30, write_only=True, required=False)

    class Meta:
        model = User
        fields = ('username', 'password', 'email', 'first_name', 'current_password')
        # 默认非必填
        extra_kwargs = {
            'username': {'read_only': True},
            'password': {'write_only': True, 'required': False},
        }

    def validate(self, attrs):
        # 当修改密码时，需要验证当前密码是否正确
        if 'password' in attrs:  # 修改密码
            current_password = attrs.get('current_password')
            if current_password is None:
                raise serializers.ValidationError('需要提供旧密码')
            if not self.instance.check_password(current_password):
                raise serializers.ValidationError('验证当前密码错误')
        return attrs

    def update(self, instance, validated_data):
        print(validated_data)
        for key, value in validated_data.items():
            setattr(instance, key, value)
        if 'password' in validated_data:
            instance.set_password(validated_data['password'])
        instance.save()
        return instance
