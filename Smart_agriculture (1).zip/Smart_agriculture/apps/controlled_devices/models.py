from django.db import models
from django.utils import timezone


# Create your models here.
# 可控器件设备表
class Device(models.Model):
    index = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=30)
    device_type = models.CharField(max_length=30)


# 高亮LED灯历史状态表
class DeviceHistoryLight(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=111)
    brightness = models.IntegerField(default=0)
    time = models.DateTimeField(default=timezone.now)


# 风机历史状态表
class DeviceHistoryFan(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=171)
    fan = models.BooleanField(default=False)
    time = models.DateTimeField(default=timezone.now)


# 舵机历史状态表
class DeviceHistoryEngine(models.Model):
    device_index = models.ForeignKey('Device', on_delete=models.CASCADE, default=161)
    engine = models.BooleanField(default=False)
    time = models.DateTimeField(default=timezone.now)


# 自动模式开启历史
class AutoControlHistory(models.Model):
    automode = models.BooleanField(default=False)
    time = models.DateTimeField(default=timezone.now)
