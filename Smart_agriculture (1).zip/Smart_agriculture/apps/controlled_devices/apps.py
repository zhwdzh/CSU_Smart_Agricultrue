from django.apps import AppConfig


class ControlledDevicesConfig(AppConfig):
    name = 'controlled_devices'
