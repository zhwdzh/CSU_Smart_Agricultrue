from django.urls import path
from .views import *

app_name = '[controlled_devices]'


urlpatterns = [
    path('light/<str:start>/<str:end>', LightHistoryView.as_view(), name="light"),       # 获取高亮LED灯历史状态信息路径
    path('fan/<str:start>/<str:end>', FanHistoryView.as_view(), name="fan"),             # 获取风机历史状态信息路径
    path('engine/<str:start>/<str:end>', EngineHistoryView.as_view(), name="engine"),    # 获取舵机历史状态信息路径
    path('autocontrol/<str:start>/<str:end>', AutoControlHistoryView.as_view(), name="autocontrol"),
    path('lightchange', LightChangeView.as_view(), name='lightchange'),                  # 改变高亮LED灯状态路径
    path('fanchange', FanChangeView.as_view(), name='fanchange'),                        # 改变风机状态路径
    path('enginechange', EngineChangeView.as_view(), name='enginechange'),               # 改变舵机状态路径
    path('autocontrolchange', AutoControlChangeView.as_view(), name='autocontrolchange'),
]
