from django.db.models import Q
from django.shortcuts import render
from rest_framework import status
from rest_framework.generics import ListAPIView, UpdateAPIView, CreateAPIView
from rest_framework.response import Response
from rest_framework.utils import json

from .serializers import *
from socket import socket, AF_INET, SOCK_STREAM


# Create your views here.
# 高亮LED灯历史状态信息视图
class LightHistoryView(ListAPIView):
    queryset = DeviceHistoryLight.objects.all()
    serializer_class = LightSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return DeviceHistoryLight.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 风机历史状态信息视图
class FanHistoryView(ListAPIView):
    queryset = DeviceHistoryFan.objects.all()
    serializer_class = FanSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return DeviceHistoryFan.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 舵机历史状态信息视图
class EngineHistoryView(ListAPIView):
    queryset = DeviceHistoryEngine.objects.all()
    serializer_class = EngineSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return DeviceHistoryEngine.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 控制高亮LED灯,向数据库中插入数据，并发送信息至中间层
class LightChangeView(CreateAPIView):
    queryset = DeviceHistoryLight.objects.last()
    serializer_class = LightChangeSerializer

    def post(self, request, *args, **kwargs):
        brightness = request.data.get('brightness', None)
        HOST = "192.168.43.194"
        PORT = 10001
        send_content = json.dumps({"brightness": brightness, "device_index": 111})
        # send_content = '{"msg_type": "order", "scene_code":"' + scene_code + '","device":"' + device + '",
        # "content":"' \ + operate + '"}'
        content = send_content + "\r\n\r\n"
        try:
            s = socket(AF_INET, SOCK_STREAM)
            s.connect((HOST, PORT))
            s.send(content.encode(encoding='utf-8'))
            print(send_content + "发送成功")
            s.close()
        except:
            return Response(data={'code': 400, 'detail': '操作失败'}, status=status.HTTP_400_BAD_REQUEST)
        return self.create(request, *args, **kwargs)


# 控制风机,向数据库中插入数据，并发送信息至中间层
class FanChangeView(CreateAPIView):
    queryset = DeviceHistoryFan.objects.last()
    serializer_class = FanChangeSerializer

    def post(self, request, *args, **kwargs):
        fan = request.data.get('fan', None)
        HOST = "192.168.43.194"
        PORT = 10001
        send_content = json.dumps({"fan": fan, "device_index": 171})
        # send_content = '{"msg_type": "order", "scene_code":"' + scene_code + '","device":"' + device + '",
        # "content":"' \ + operate + '"}'
        content = send_content + "\r\n\r\n"
        try:
            s = socket(AF_INET, SOCK_STREAM)
            s.connect((HOST, PORT))
            s.send(content.encode(encoding='utf-8'))
            print(send_content + "发送成功")
            s.close()
        except:
            return Response(data={'code': 400, 'detail': '操作失败'}, status=status.HTTP_400_BAD_REQUEST)
        return self.create(request, *args, **kwargs)


# 控制舵机,向数据库中插入数据，并发送信息至中间层
class EngineChangeView(CreateAPIView):
    queryset = DeviceHistoryEngine.objects.last()
    serializer_class = EngineChangeSerializer

    def post(self, request, *args, **kwargs):
        engine = request.data.get('engine', None)
        HOST = "192.168.43.194"
        PORT = 10001
        send_content = json.dumps({"engine": engine, "device_index": 161})
        # send_content = '{"msg_type": "order", "scene_code":"' + scene_code + '","device":"' + device + '",
        # "content":"' \ + operate + '"}'
        content = send_content + "\r\n\r\n"
        try:
            s = socket(AF_INET, SOCK_STREAM)
            s.connect((HOST, PORT))
            s.send(content.encode(encoding='utf-8'))
            print(send_content + "发送成功")
            s.close()
        except:
            return Response(data={'code': 400, 'detail': '操作失败'}, status=status.HTTP_400_BAD_REQUEST)
        return self.create(request, *args, **kwargs)


# 自动控制模式历史状态信息视图
class AutoControlHistoryView(ListAPIView):
    queryset = AutoControlHistory.objects.all()
    serializer_class = AutoControlSerializer

    def get_queryset(self):
        starttime = self.kwargs.get('start')
        endtime = self.kwargs.get('end')
        return AutoControlHistory.objects.filter(Q(time__gt=starttime) & Q(time__lt=endtime)).extra(
            select={"time": "DATE_FORMAT(time, '%%Y-%%m-%%d %%H:%%i:%%s')"})


# 改变控制模式
class AutoControlChangeView(CreateAPIView):
    queryset = AutoControlHistory.objects.last()
    serializer_class = AutoControlChangeSerializer
