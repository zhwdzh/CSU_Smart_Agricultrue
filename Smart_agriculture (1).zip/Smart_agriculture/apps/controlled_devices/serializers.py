from apps.controlled_devices.models import *
from rest_framework import serializers


# 高亮LED灯历史状态信息序列化
class LightSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryLight
        fields = '__all__'   # 序列化Light中所有字段


# 改变高亮LED灯状态
class LightChangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryLight
        fields = ['brightness']


# 风机历史状态信息序列化
class FanSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryFan
        fields = '__all__'   # 序列化Light中所有字段


# 改变风机状态
class FanChangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryFan
        fields = ['fan']


# 舵机历史状态信息序列化
class EngineSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryEngine
        fields = '__all__'   # 序列化Light中所有字段


# 改变舵机状态
class EngineChangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceHistoryEngine
        fields = ['engine']


# 自动控制模式历史状态信息序列化
class AutoControlSerializer(serializers.ModelSerializer):
    class Meta:
        model = AutoControlHistory
        fields = '__all__'   # 序列化Light中所有字段


# 改变舵机状态
class AutoControlChangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AutoControlHistory
        fields = ['automode']
