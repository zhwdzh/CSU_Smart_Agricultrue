from rest_framework import serializers
from apps.logs.models import *

# 环境参数序列化
# from logs.models import Logs


class LogsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Logs
        fields = '__all__'  # 序列化devices中所有字段


class AutoLogsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AutoLogs
        fields = '__all__'  # 序列化devices中所有字段
