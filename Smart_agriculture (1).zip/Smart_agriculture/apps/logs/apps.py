from django.apps import AppConfig


class LogsConfig(AppConfig):
    name = 'logs'
