from django.shortcuts import render
from django.views.generic import ListView
from rest_framework import mixins
from rest_framework.generics import GenericAPIView, CreateAPIView, ListAPIView
from django.db import connection
from apps.logs.models import *
from apps.logs.serializers import *


# Create your views here.
def add_logs(LogType, LogContent, LogIp, UserId):
    # 将接受的各个数据存储到日志表中
    InsCmd = "insert into logs_logs(add_time, log_type, log_content, log_ip, user_id) " \
            "values(CURRENT_TIMESTAMP,'%s','%s','%s','%s');"
    cmd = InsCmd % (LogType, LogContent, LogIp, UserId)
    print(cmd)
    cursor = connection.cursor()
    cursor.execute(cmd)
    cursor.close()
    return


def add_autologs(deviceid, devicename, logcontent):
    # 将接受的各个数据存储到日志表中
    InsCmd = "insert into logs_autologs(add_time, device_id, device_name, log_content) " \
            "values(CURRENT_TIMESTAMP,'%s','%s','%s');"
    cmd = InsCmd % (deviceid, devicename, logcontent)
    cursor = connection.cursor()
    cursor.execute(cmd)
    cursor.close()
    return


class LogsView(ListAPIView, CreateAPIView):
    permission_classes = []  # 该接口不需要任何权限
    queryset = Logs.objects.all()
    serializer_class = LogsSerializer

    # @swagger_auto_schema(**user_read_swagger)
    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    # 封装一个新增日志的函数


class AutoLogsView(ListAPIView, CreateAPIView):
    permission_classes = []  # 该接口不需要任何权限
    queryset = AutoLogs.objects.all()
    serializer_class = AutoLogsSerializer

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)
