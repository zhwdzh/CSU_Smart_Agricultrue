from django.contrib.auth.models import User
from django.db import models

# Create your models here.
from django.db import models
import datetime


# Create your models here.

# xxx  时间  做了一件什么事情  ip  所属模块
from django.utils import timezone


class Logs(models.Model):
    add_time = models.DateTimeField(verbose_name='日志添加时间', default=datetime.datetime.now)
    log_type = models.CharField(verbose_name='所属模块、操作类型', max_length=255)
    log_content = models.CharField(verbose_name='日志内容', max_length=255)
    log_ip = models.CharField(verbose_name='访问ip', max_length=20)
    user = models.ForeignKey(User, on_delete=models.PROTECT)


class AutoLogs(models.Model):
    add_time = models.DateTimeField(verbose_name='日志添加时间', default=timezone.now)
    device_id = models.IntegerField(verbose_name='设备号')
    device_name = models.CharField(verbose_name='设备名称', max_length=30)
    log_content = models.CharField(verbose_name='日志内容', max_length=255)
