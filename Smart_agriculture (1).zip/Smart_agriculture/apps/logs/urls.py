from django.urls import path
from apps.logs.views import *

app_name = '[logs]'

urlpatterns = [
    # 用户列表和新增
    path('logs', LogsView.as_view(), name="logs"),
]
